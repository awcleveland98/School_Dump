package finalProject;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import javax.swing.JPanel;

public class Graph extends JPanel {
	private Stack<Object> yStack1;
	private Stack<Object> yStack2;
	
	private double m1 = 0;
	private double b1 = 0;
	private int e1XType;
	
	private double m2 = 0;
	private double b2 = 0;
	private int e2XType;
	
	public Graph() {
		m1 = 0;
		b1 = 0;
		m2 = 0;
		b2 = 0;
		
	}

	public void setEquation1(double m, double b, int xType) {
		
		this.m1 = m/100;
		this.b1 = b*10;
		this.e1XType = xType;
	}
	
	public void setEquation2(double m, double b, int xType) {
		this.m2 = m/100;
		this.b2 = b*10;
		this.e2XType = xType;
	}
	
	public void fillStack() {
		
		yStack1 = new Stack<>();
		yStack2 = new Stack<>();
		
		double y1 = 0;
		double y2 = 0;
		
		
		if(e1XType == 0) {//for x
			for (double i = -244; i < 244; i++) {
				
				y1 = (-this.m1*100 * i) + -this.b1;
				Coordinate cords1 = new Coordinate(i+244,y1+179);
				yStack1.push(cords1);
				
			}
		}
		if (e2XType == 0) {//for x
			for (double i = -244; i < 244; i++) {
				
				y2 = (-this.m2*100 * i) + -this.b2;
				Coordinate cords2 = new Coordinate(i+244,y2+179);
				yStack2.push(cords2);
				
			}
		}
		
		if(e1XType == 1) {//for x^2
			for (double i = -244; i < 244; i++) {
				
				y1 = (-this.m1 * i*i) + -this.b1;
				Coordinate cords1 = new Coordinate(i+244,y1+179);
				yStack1.push(cords1);
				
			}
		}
		if (e2XType == 1) {//for x^2
			for (double i = -244; i < 244; i++) {
				
				y2 = (-this.m2 * i*i) + -this.b2;
				Coordinate cords2 = new Coordinate(i+244,y2+179);
				yStack2.push(cords2);
				
			}
		}
		
		if(e1XType == 2) {//for x^3
			for (double i = -244; i < 244; i++) {
				
				y1 = (-this.m1/100 * i*i*i) + -this.b1;
				Coordinate cords1 = new Coordinate(i+244,y1+179);
				yStack1.push(cords1);
				
			}
		}
		if (e2XType == 2) {//for x^3
			for (double i = -244; i < 244; i++) {
				
				y2 = (-this.m2/100 * i*i*i) + -this.b2;
				Coordinate cords2 = new Coordinate(i+244,y2+179);
				yStack2.push(cords2);
				
			}
		}
		
		
		
		
		
		
		
		paintComponent(getGraphics());
		Coordinate c1 = new Coordinate();
		Coordinate c2 = new Coordinate();
		
		for (double i = -244; i < 244; i++) {
			Graphics2D g2 = (Graphics2D) getGraphics();
			
			
			
			c1 = (Coordinate) yStack1.pop();
			c2 = (Coordinate) yStack2.pop();
			
			//getGraphics().fillRect((int) c.getX(), (int)c.getY(), 1, 1);
			
			Rectangle2D rect1 = new Rectangle2D.Double(c1.getX(),c1.getY(),1,1);
			Rectangle2D rect2 = new Rectangle2D.Double(c2.getX(),c2.getY(),1,1);
			
			
			
			g2.fill(rect1);
			g2.fill(rect2);
			
			
		}
		
	}
	
	
	
	public void paintComponent(Graphics g) {
		super.paintComponents(g);
		
		
		g.setColor(Color.BLACK);
		g.fillRect(244, 0, 1, 359);//x-axis
		g.fillRect(0, 179, 489, 1);//y-axis
	}
	
	public void clearGraph() {
		super.paintComponent(getGraphics());
		super.paint(getGraphics());
	}
}
