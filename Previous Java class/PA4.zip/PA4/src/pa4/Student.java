package pa4;

public class Student extends Person{

	private double gpa;
	private String major;
	
	public Student() {
		
	}
	Student(double gpa, String major, String fname, String lname, String address, String phNumber){
		super(fname, lname, address, phNumber);
		this.gpa = gpa;
		this.major = major;
		
	}
	
	public double getGpa(){
		return gpa;
	}
	public void setGpa(){
		this.gpa = gpa;
	}
	
	public String getMajor(){
		return major;
	}
	public void setMajor(){
		this.major = major;
	}
	
	@Override
	public String toString(){
		return "\tFirst Name: " + getFirstName() + "\n\tLastName: "
				+ getLastName() + "\n\tAddress: " + getAddress() + "\n\tPhone: "
				+ getPhoneNumber() + "\n\tMajor: " + major +"\n\tGPA: " + gpa;
	}
	
	
}
