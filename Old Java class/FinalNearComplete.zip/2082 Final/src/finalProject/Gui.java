package finalProject;


import java.awt.*;
import java.io.*;
import javax.swing.*;
import javax.swing.plaf.synth.SynthSplitPaneUI;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Gui extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField txtDisplay;
	private Graph graph;
	private JTextField equation1BTxtField;
	private JTextField equation2BTxtField;
	private JTextField equation1MTxtField;
	private JTextField equation2MTxtField;
	
	private JComboBox equation1ComboBox;
	private JComboBox equation2ComboBox;
	
	double fnum;
	double snum;
	double result;
	String operations= null;
	String answer;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Gui frame = new Gui();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Gui() {
		getContentPane().setFont(new Font("Tahoma", Font.BOLD, 14));
		
		graph = new Graph();
		graph.setSize(489, 359);
		graph.setLocation(10, 305);
		getContentPane().add(graph);
		
		setTitle("Standard Calculator");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 525, 800);
		getContentPane().setLayout(null);
		
		txtDisplay = new JTextField();
		txtDisplay.setBounds(10, 11, 243, 37);
		getContentPane().add(txtDisplay);
		txtDisplay.setColumns(10);
		
		JButton btn4 = new JButton("4");
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String num = txtDisplay.getText() + btn4.getText();
				txtDisplay.setText(num);
			}
		});
		btn4.setFont(new Font("Tahoma", Font.BOLD, 14));
		btn4.setBounds(8, 149, 46, 47);
		getContentPane().add(btn4);
		
		JButton btn7 = new JButton("7");
		btn7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String num = txtDisplay.getText() + btn7.getText();
				txtDisplay.setText(num);
			}
		});
		btn7.setFont(new Font("Tahoma", Font.BOLD, 14));
		btn7.setBounds(8, 100, 46, 47);
		getContentPane().add(btn7);
		
		JButton btn8 = new JButton("8");
		btn8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String num = txtDisplay.getText() + btn8.getText();
				txtDisplay.setText(num);
			}
		});
		btn8.setFont(new Font("Tahoma", Font.BOLD, 14));
		btn8.setBounds(58, 100, 46, 47);
		getContentPane().add(btn8);
		
		JButton backBtn = new JButton("\uF0E7");
		backBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String backspace = null;
				if(txtDisplay.getText().length() > 0) {
					StringBuilder builder = new StringBuilder(txtDisplay.getText());
					builder.deleteCharAt(txtDisplay.getText().length() - 1);
					backspace = builder.toString();
					txtDisplay.setText(backspace);
				}
			}
		});
		backBtn.setFont(new Font("Wingdings", Font.PLAIN, 11));
		backBtn.setBounds(8, 51, 46, 47);
		getContentPane().add(backBtn);
		
		JButton clearBtn = new JButton("C");
		clearBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtDisplay.setText(null);
			}
		});
		clearBtn.setFont(new Font("Tahoma", Font.BOLD, 14));
		clearBtn.setBounds(58, 51, 46, 47);
		getContentPane().add(clearBtn);
		
		JButton btn1 = new JButton("1");
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String num = txtDisplay.getText() + btn1.getText();
				txtDisplay.setText(num);
			}
		});
		btn1.setFont(new Font("Tahoma", Font.BOLD, 14));
		btn1.setBounds(8, 198, 46, 47);
		getContentPane().add(btn1);
		
		JButton btn0 = new JButton("0");
		btn0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String num = txtDisplay.getText() + btn0.getText();
				txtDisplay.setText(num);
			}
		});
		btn0.setFont(new Font("Tahoma", Font.BOLD, 14));
		btn0.setBounds(8, 247, 96, 47);
		getContentPane().add(btn0);
		
		JButton historyBtn = new JButton("H");
		historyBtn.setFont(new Font("Tahoma", Font.BOLD, 14));
		historyBtn.setBounds(108, 51, 46, 47);
		getContentPane().add(historyBtn);
		
		JButton divideBtn = new JButton("/");
		divideBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fnum = Double.parseDouble(txtDisplay.getText());
				txtDisplay.setText("");
				operations = "/";
			}
		});
		divideBtn.setFont(new Font("Tahoma", Font.BOLD, 14));
		divideBtn.setBounds(158, 51, 46, 47);
		getContentPane().add(divideBtn);
		
		JButton parenBtn = new JButton("()");
		parenBtn.setFont(new Font("Tahoma", Font.BOLD, 14));
		parenBtn.setBounds(208, 51, 46, 47);
		getContentPane().add(parenBtn);
		
		JButton percBtn = new JButton("%");
		percBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double pom = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				pom = pom / 100;
				txtDisplay.setText(String.valueOf(pom));
			}
		});
		percBtn.setFont(new Font("Tahoma", Font.PLAIN, 11));
		percBtn.setBounds(208, 100, 46, 47);
		getContentPane().add(percBtn);
		
		JButton btnx = new JButton("1/x");
		btnx.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double pom = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				pom = 1 / pom;
				txtDisplay.setText(String.valueOf(pom));
			}
		});
		btnx.setFont(new Font("Tahoma", Font.PLAIN, 9));
		btnx.setBounds(208, 149, 46, 47);
		getContentPane().add(btnx);
		
		JButton equalBtn = new JButton("=");
		equalBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				snum = Double.parseDouble(txtDisplay.getText());
				if (operations == "+")
				{
					result = fnum + snum;
					answer = String.format("%.2f", result);
					txtDisplay.setText(answer);
				}
				else if (operations == "-")
				{
					result = fnum - snum;
					answer = String.format("%.2f", result);
					txtDisplay.setText(answer);
				}
				else if (operations == "/")
				{
					result = fnum / snum;
					answer = String.format("%.2f", result);
					txtDisplay.setText(answer);
				}
				else if (operations == "*")
				{
					result = fnum * snum;
					answer = String.format("%.2f", result);
					txtDisplay.setText(answer);
				}
				else if (operations == "^")
				{
					result = Math.pow(fnum, snum);
					answer = String.format("%.2f", result);
					txtDisplay.setText(answer);
				}
				
			}
		});
		equalBtn.setFont(new Font("Tahoma", Font.BOLD, 14));
		equalBtn.setBounds(208, 198, 46, 97);
		getContentPane().add(equalBtn);
		
		JButton btn9 = new JButton("9");
		btn9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String num = txtDisplay.getText() + btn9.getText();
				txtDisplay.setText(num);
			}
		});
		btn9.setFont(new Font("Tahoma", Font.BOLD, 14));
		btn9.setBounds(108, 100, 46, 47);
		getContentPane().add(btn9);
		
		JButton multBtn = new JButton("*");
		multBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fnum = Double.parseDouble(txtDisplay.getText());
				txtDisplay.setText("");
				operations = "*";
			}
		});
		multBtn.setFont(new Font("Tahoma", Font.BOLD, 14));
		multBtn.setBounds(158, 100, 46, 47);
		getContentPane().add(multBtn);
		
		JButton btn5 = new JButton("5");
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String num = txtDisplay.getText() + btn5.getText();
				txtDisplay.setText(num);
			}
		});
		btn5.setFont(new Font("Tahoma", Font.BOLD, 14));
		btn5.setBounds(58, 149, 46, 47);
		getContentPane().add(btn5);
		
		JButton btn6 = new JButton("6");
		btn6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String num = txtDisplay.getText() + btn6.getText();
				txtDisplay.setText(num);
			}
		});
		btn6.setFont(new Font("Tahoma", Font.BOLD, 14));
		btn6.setBounds(108, 149, 46, 47);
		getContentPane().add(btn6);
		
		JButton subBtn = new JButton("-");
		subBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fnum = Double.parseDouble(txtDisplay.getText());
				txtDisplay.setText("");
				operations = "-";
			}
		});
		subBtn.setFont(new Font("Tahoma", Font.BOLD, 14));
		subBtn.setBounds(158, 149, 46, 47);
		getContentPane().add(subBtn);
		
		JButton btn2 = new JButton("2");
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String num = txtDisplay.getText() + btn2.getText();
				txtDisplay.setText(num);
			}
		});
		btn2.setFont(new Font("Tahoma", Font.BOLD, 14));
		btn2.setBounds(58, 198, 46, 47);
		getContentPane().add(btn2);
		
		JButton btn3 = new JButton("3");
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String num = txtDisplay.getText() + btn3.getText();
				txtDisplay.setText(num);
			}
		});
		btn3.setFont(new Font("Tahoma", Font.BOLD, 14));
		btn3.setBounds(108, 198, 46, 47);
		getContentPane().add(btn3);
		
		JButton addBtn = new JButton("+");
		addBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fnum = Double.parseDouble(txtDisplay.getText());
				txtDisplay.setText("");
				operations = "+";
			}
		});
		addBtn.setFont(new Font("Tahoma", Font.BOLD, 14));
		addBtn.setBounds(158, 198, 46, 47);
		getContentPane().add(addBtn);
		
		JButton dotBtn = new JButton(".");
		dotBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String num = txtDisplay.getText() + dotBtn.getText();
				txtDisplay.setText(num);
			}
		});
		dotBtn.setFont(new Font("Tahoma", Font.BOLD, 14));
		dotBtn.setBounds(108, 247, 46, 47);
		getContentPane().add(dotBtn);
		
		JButton plusMinusBtn = new JButton("\u00B1");
		plusMinusBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double pom = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				pom = pom * (-1);
				txtDisplay.setText(String.valueOf(pom));
			}
		});
		plusMinusBtn.setFont(new Font("Tahoma", Font.BOLD, 14));
		plusMinusBtn.setBounds(158, 247, 46, 47);
		getContentPane().add(plusMinusBtn);
		
		JButton cosBtn = new JButton("Cos");
		cosBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double pom = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				pom = Math.cos(pom);
				txtDisplay.setText(String.valueOf(pom));
			}
		});
		cosBtn.setBounds(319, 51, 60, 47);
		getContentPane().add(cosBtn);
		
		JButton tanBtn = new JButton("Tan");
		tanBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double pom = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				pom = Math.tan(pom);
				txtDisplay.setText(String.valueOf(pom));
			}
		});
		tanBtn.setBounds(379, 51, 60, 47);
		getContentPane().add(tanBtn);
		
		JButton sinBtn = new JButton("Sin");
		sinBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double pom = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				pom = Math.sin(pom);
				txtDisplay.setText(String.valueOf(pom));
			}
		});
		sinBtn.setBounds(259, 51, 60, 47);
		getContentPane().add(sinBtn);
		
		JButton sqrtBtn = new JButton("\u221A");
		sqrtBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double pom = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				pom = Math.sqrt(pom);
				txtDisplay.setText(String.valueOf(pom));
			}
		});
		sqrtBtn.setBounds(439, 51, 60, 47);
		getContentPane().add(sqrtBtn);
		
		JButton aSinBtn = new JButton("ASin");
		aSinBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double pom = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				pom = Math.asin(pom);
				txtDisplay.setText(String.valueOf(pom));
			}
		});
		aSinBtn.setFont(new Font("Tahoma", Font.PLAIN, 11));
		aSinBtn.setBounds(259, 100, 60, 47);
		getContentPane().add(aSinBtn);
		
		JButton aCosBtn = new JButton("ACos");
		aCosBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double pom = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				pom = Math.acos(pom);
				txtDisplay.setText(String.valueOf(pom));
			}
		});
		aCosBtn.setFont(new Font("Tahoma", Font.PLAIN, 11));
		aCosBtn.setBounds(319, 100, 60, 47);
		getContentPane().add(aCosBtn);
		
		JButton aTanBtn = new JButton("ATan");
		aTanBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double pom = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				pom = Math.atan(pom);
				txtDisplay.setText(String.valueOf(pom));
			}
		});
		aTanBtn.setFont(new Font("Tahoma", Font.PLAIN, 11));
		aTanBtn.setBounds(379, 100, 60, 47);
		getContentPane().add(aTanBtn);
		
		JButton cbrtBtn = new JButton("Cbrt");
		cbrtBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double pom = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				pom = Math.cbrt(pom);
				txtDisplay.setText(String.valueOf(pom));
			}
		});
		cbrtBtn.setFont(new Font("Tahoma", Font.PLAIN, 11));
		cbrtBtn.setBounds(439, 100, 60, 47);
		getContentPane().add(cbrtBtn);
		
		JButton logBtn = new JButton("Log");
		logBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double pom = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				pom = Math.log(pom);
				txtDisplay.setText(String.valueOf(pom));
			}
		});
		logBtn.setBounds(259, 149, 60, 47);
		getContentPane().add(logBtn);
		
		JButton lnBtn = new JButton("Ln");
		lnBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double pom = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				pom = (-Math.log(1-pom))/pom;
				txtDisplay.setText(String.valueOf(pom));
			}
		});
		lnBtn.setBounds(319, 149, 60, 47);
		getContentPane().add(lnBtn);
		
		JButton piBtn = new JButton("\u03C0");
		piBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double pom = Math.PI;
				txtDisplay.setText(String.valueOf(pom));
			}
		});
		piBtn.setBounds(379, 149, 60, 47);
		getContentPane().add(piBtn);
		
		JButton eulerBtn = new JButton("e");
		eulerBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double pom = Math.E;
				txtDisplay.setText(String.valueOf(pom));
			}
		});
		eulerBtn.setFont(new Font("Tahoma", Font.BOLD, 14));
		eulerBtn.setBounds(439, 149, 60, 47);
		getContentPane().add(eulerBtn);
		
		JButton powerBtn = new JButton("x^y");
		powerBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fnum = Double.parseDouble(txtDisplay.getText());
				txtDisplay.setText("");
				operations = "^";
			}
		});
		powerBtn.setBounds(259, 198, 60, 47);
		getContentPane().add(powerBtn);
		
		JButton squareBtn = new JButton("x^2");
		squareBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double pom = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				pom = Math.pow(pom, 2);
				txtDisplay.setText(String.valueOf(pom));
			}
		});
		squareBtn.setBounds(319, 198, 60, 47);
		getContentPane().add(squareBtn);
		
		JButton cubeBtn = new JButton("x^3");
		cubeBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double pom = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				pom = Math.pow(pom, 3);
				txtDisplay.setText(String.valueOf(pom));
			}
		});
		cubeBtn.setBounds(379, 198, 60, 47);
		getContentPane().add(cubeBtn);
		
		JButton absoluteBtn = new JButton("|x|");
		absoluteBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double pom = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				pom = Math.abs(pom);
				txtDisplay.setText(String.valueOf(pom));
			}
		});
		absoluteBtn.setBounds(439, 198, 60, 47);
		getContentPane().add(absoluteBtn);
		
		JButton eulerPowerBtn = new JButton("e^x");
		eulerPowerBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double pom = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				pom = Math.pow(Math.E, pom);
				txtDisplay.setText(String.valueOf(pom));
			}
		});
		eulerPowerBtn.setBounds(259, 247, 60, 47);
		getContentPane().add(eulerPowerBtn);
		
		JButton factBtn = new JButton("x!");
		factBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				double pom = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				pom = fact(pom);
				txtDisplay.setText(String.valueOf(pom));
			}
		});
		factBtn.setBounds(319, 247, 60, 47);
		getContentPane().add(factBtn);
		
	
		
		
		equation1BTxtField = new JTextField();
		equation1BTxtField.setBounds(168, 675, 45, 25);
		getContentPane().add(equation1BTxtField);
		equation1BTxtField.setColumns(10);
		
		equation2BTxtField = new JTextField();
		equation2BTxtField.setBounds(168, 711, 45, 25);
		getContentPane().add(equation2BTxtField);
		equation2BTxtField.setColumns(10);
		
		JLabel lblEquation = new JLabel("Equation 1");
		lblEquation.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblEquation.setBounds(223, 675, 86, 20);
		getContentPane().add(lblEquation);
		
		JLabel lblEquation_1 = new JLabel("Equation 2");
		lblEquation_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblEquation_1.setBounds(223, 706, 86, 20);
		getContentPane().add(lblEquation_1);
		
		JButton graphBtn = new JButton("Graph");
		graphBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				double m1 = 0, m2 = 0, b1 = 0, b2 = 0;
				int x1 = 0, x2 = 0;
				
				if (!equation1MTxtField.getText().isEmpty()) {
					m1 = Double.parseDouble(equation1MTxtField.getText());
					
				} else {
					
					m1 = 0;
				}
				
				if (!equation1BTxtField.getText().isEmpty()) {
					
					b1 = Double.parseDouble(equation1BTxtField.getText());
					
				} else {
					
					b1 = 0;
				}
				
				if (!equation2MTxtField.getText().isEmpty()) {
					m2 = Double.parseDouble(equation2MTxtField.getText());
				} else {
					m2 = 0;
				}
				
				if (!equation2BTxtField.getText().isEmpty()) {
					b2 = Double.parseDouble(equation2BTxtField.getText());
				} else {
					b2 = 0;
				}
					
				x1 = equation1ComboBox.getSelectedIndex();
				x2 = equation2ComboBox.getSelectedIndex();
				
				graph.setEquation1(m1, b1, x1);
				
				graph.setEquation2(m2, b2, x2);
				
			
				
				graph.fillStack();
				
				
			}
		});
		graphBtn.setBounds(416, 675, 72, 54);
		getContentPane().add(graphBtn);
		
		JLabel equationLbl1 = new JLabel("y =                             + ");
		equationLbl1.setFont(new Font("Tahoma", Font.BOLD, 14));
		equationLbl1.setBounds(10, 675, 155, 20);
		getContentPane().add(equationLbl1);
		
		JLabel lblNewLabel_1 = new JLabel("y =                             + ");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(10, 709, 155, 17);
		getContentPane().add(lblNewLabel_1);
		
		equation1MTxtField = new JTextField();
		equation1MTxtField.setBounds(40, 677, 45, 25);
		getContentPane().add(equation1MTxtField);
		equation1MTxtField.setColumns(10);
		
		equation2MTxtField = new JTextField();
		equation2MTxtField.setBounds(40, 708, 45, 25);
		getContentPane().add(equation2MTxtField);
		equation2MTxtField.setColumns(10);
		
		JButton clearGraphBtn = new JButton("Clear");
		clearGraphBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				graph.clearGraph();
				
				equation1MTxtField.setText("");
				equation1BTxtField.setText("");
				equation2MTxtField.setText("");
				equation2BTxtField.setText("");
			}
		});
		clearGraphBtn.setBounds(319, 675, 72, 54);
		getContentPane().add(clearGraphBtn);
		
		equation1ComboBox = new JComboBox();
		equation1ComboBox.setModel(new DefaultComboBoxModel(new String[] {"x", "x^2", "x^3", "1/x"}));
		equation1ComboBox.setBounds(95, 678, 50, 20);
		getContentPane().add(equation1ComboBox);
		
		equation2ComboBox = new JComboBox();
		equation2ComboBox.setModel(new DefaultComboBoxModel(new String[] {"x", "x^2", "x^3", "1/x"}));
		equation2ComboBox.setBounds(95, 711, 50, 20);
		getContentPane().add(equation2ComboBox);
		
		JButton binBtn = new JButton("BIN");
		binBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int pom = Integer.parseInt(txtDisplay.getText());
				txtDisplay.setText(Integer.toString(pom, 2));
			}
		});
		binBtn.setBounds(379, 247, 60, 47);
		getContentPane().add(binBtn);
		
		JButton hexBtn = new JButton("HEX");
		hexBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int pom = Integer.parseInt(txtDisplay.getText());
				txtDisplay.setText(Integer.toString(pom, 16));
			}
		});
		hexBtn.setBounds(439, 247, 60, 47);
		getContentPane().add(hexBtn);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("File");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmStandard = new JMenuItem("Standard");
		mntmStandard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				setTitle("Standard Calculator");
				setBounds(100, 100, 275, 367);
				txtDisplay.setBounds(10, 11, 243, 37);
			}
		});
		
		mnNewMenu.add(mntmStandard);
		
		JMenuItem mntmScientific = new JMenuItem("Scientific");
		mntmScientific.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				setTitle("Scientific Calculator");
				setBounds(100, 100, 525, 367);
				txtDisplay.setBounds(10, 11, 494, 37);
				
			}
		});
		mnNewMenu.add(mntmScientific);
		
		JMenuItem mntmExit = new JMenuItem("Exit");
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		
		JMenuItem mntmGraphing = new JMenuItem("Graphing");
		mntmGraphing.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				setTitle("Graphing Calculator");
				setBounds(100, 100, 525, 800);
				txtDisplay.setBounds(10, 11, 494, 37);
				
			}
		});
		mnNewMenu.add(mntmGraphing);
		mnNewMenu.add(mntmExit);
	}
	public double fact(double n) {
		if (n == 0) return 1;
		else 
			return n * fact(n-1);
	}
}
