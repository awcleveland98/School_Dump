package edu.century.finalProject;

{
	switch (operator2) {
		case SINE :
			result = Math.sin(rightOp);
			break;
		case COSINE :
			result = Math.cos(rightOp);
			break;
		case TANGENT :
			result = Math.tan(rightOp);
			break;
		case ARCSIN :
			result = Math.asin(rightOp);
			break;
		case ARCCOSINE :
			result = Math.acos(rightOp);
			break;
		case ARCTANGENT :
			result = Math.atan(rightOp);
			break;
		case SQUAREROOT :
			result = Math.sqrt(rightOp);
			break;
		case CUBEROOT :
			result = Math.cbrt(rightOp);
			break;
		case LOG :
			result = Math.log(rightOp);
			break;
		case LN :
			result = (-Math.log(1 - rightOp)) / rightOp;
			break;
		case PI :
			result = Math.PI;
			break;
		case EULER :
			result = Math.E;
			break;
		case POWER :
			result = Math.pow(leftOp, rightOp);
			break;
		case SQUARED :
			result = Math.pow(leftOp, 2);
			break;
		case CUBED :
			result = Math.pow(leftOp, 3);
			break;
		case ABSOLUTE :
			result = Math.abs(rightOp);
			break;
		case EULERPOWER :
			result = Math.pow(Math.E, rightOp);
			break;
		case FACTORIAL :
		
			
		case FRACTION :
			result = 1 / rightOp;
			break;
		default : 
			result = 0;
	}

