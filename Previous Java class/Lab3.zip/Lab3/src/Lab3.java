import java.util.Scanner;
import java.text.NumberFormat;

public class Lab3 {
public static void main(String[] args){

Scanner input = new Scanner (System.in);
NumberFormat defaultFormat = NumberFormat.getCurrencyInstance();

System.out.println("Enter the distance of the commute in miles: ");	
double miles = input.nextDouble();
System.out.println("Enter the number of miles your car gets to the gallon: ");
double mtg = input.nextDouble();
System.out.println("Enter the price of a gallon of gas as a decimal number: ");
double pog= input.nextDouble();

double fcr = ((miles / mtg)* pog);

if (fcr >= 40){
System.out.println("For a trip of " + miles + "miles, with a consumption rate of " + mtg + "miles per gallon, and a cost of " + pog + " per gallon of gas, your trip will cost you " + fcr + "your car's gas consumption is: Excellant" + defaultFormat.format(pog));
}
if (fcr <= 20){
System.out.println("For a trip of " + miles + "miles, with a consumption rate of " + mtg + "miles per gallon, and a cost of " + pog + " per gallon of gas, your trip will cost you " + fcr + "your car's gas consumption is: Bad" + defaultFormat.format(pog));
}
if (fcr < 20 && fcr > 40){
System.out.println("For a trip of " + miles + "miles, with a consumption rate of " + mtg + "miles per gallon, and a cost of " + pog + " per gallon of gas, your trip will cost you " + fcr + "your car's gas consumption is: Average" + defaultFormat.format(pog));
}

input.close();
}	
}
