package pa4;

public class Faculty extends Person{

	private double salary;
	private String department;
	boolean ftime;
	public Faculty() {
		
	}
	Faculty(double salary, String department, String fname, String lname, String address, String phNumber){
		super(fname, lname, address, phNumber);
		this.salary = salary;
		this.department = department;
	}
	public double getSalary(){
		return salary;
	}
	public void setSalary(){
		this.salary = salary;
	}
	
	public String getDepartment(){
		return department;
	}
	public void setDepartment(){
		this.department = department;
	}
	
	public boolean isFullTime(){
		return ftime;
	}
	
	@Override
	public String toString(){
		return "\tFirst Name: " + getFirstName() + "\n\tLastName: "
				+ getLastName() + "\n\tAddress: " + getAddress() + "\n\tPhone: "
				+ getPhoneNumber() + "\n\tDepartment: " + department + "\n\tFull Time: " + ftime + "\n\tSalary: " + salary;
	}
	
	
}
