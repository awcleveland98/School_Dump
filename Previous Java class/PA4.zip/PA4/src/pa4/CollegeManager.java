package pa4;

import java.util.Arrays;
import java.util.Scanner;
import java.util.List;

public class CollegeManager {
	
	private static final int SIZE = 3;
	
	public static void main(String[] args) {

		Faculty[] facultyList = new Faculty[SIZE];
		Student[] studentList = new Student[SIZE];

		Scanner input = new Scanner(System.in);
		String ftimetrue[] = { "true", "True", "TRUE" };
		String ftimefalse[] = { "false", "False", "FALSE" };
		List<String> ftimeTrue = Arrays.asList(ftimetrue);
		List<String> ftimeFalse = Arrays.asList(ftimefalse);

		Boolean error = false;
		String f[] = { "f", "F", "faculty", "Faculty" };
		String s[] = { "s", "S", "student", "Student" };
		String quit[] = { "q", "Q", "quit", "Quit" };
		List<String> userinF = Arrays.asList(f);
		List<String> userinS = Arrays.asList(s);
		List<String> userinQ = Arrays.asList(quit);
		int facultyCount = 0;
		int studentCount = 0;
		do {
			System.out.println("Which type of person's data you want to enter.");
			System.out.println("\tFor Student type S or Student");
			System.out.println("\tFor Faculty type F or Faculty");
			System.out.println("\tTo Quit type Q or Quit");
			// Input for Faculty
			if (userinF.contains(f) && facultyCount < facultyList.length) {
				error = false;
				System.out.println("Enter First Name: ");
				String fname = input.nextLine();
				System.out.println("Enter Last Name: ");
				String lname = input.nextLine();
				System.out.println("Enter Address: ");
				String address = input.nextLine();
				System.out.println("Enter Phone Number: ");
				String phNumber = input.nextLine();
				System.out.println("Enter Department: ");
				String department = input.nextLine();
				System.out.println("Enter Salary: ");
				double salary = input.nextDouble();
				System.out.println("Enter isFulltime: ");
				boolean ftime = input.nextBoolean();
				
				Faculty tmpFaculty = new Faculty(salary, department, fname, lname, address, phNumber);
				facultyList[facultyCount] = tmpFaculty;
				facultyCount++;
				
			}
			// Input for Student
			else if (userinS.contains(s)) {
				error = false;
				System.out.println("Enter First Name: ");
				String fname = input.nextLine();
				person.setFirstName(fname);
				System.out.println("Enter Last Name: ");
				String lname = input.nextLine();
				person.setLastName(lname);
				System.out.println("Enter Address ");
				String address = input.nextLine();
				person.setAddress(address);
				System.out.println("Enter Phone Number ");
				String phNumber = input.nextLine();
				person.setPhoneNumber(phNumber);
				System.out.println("Enter Major: ");
				String major = input.nextLine();
				System.out.println("Enter GPA: ");
				double gpa = input.nextDouble();

			}
			// Input for Quit
			else if (userinQ.contains(quit)) {
				error = false;
				//loop to print all faculty
				//another loop to print all students
			} else {
				error = true;
				System.err.println("Error: Incorrect Input");
			}
		} while (error == true);

	}

}
